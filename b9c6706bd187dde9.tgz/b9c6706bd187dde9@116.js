function _1(md){return(
md`# HW3 - D3 Visualization`
)}

function _d3(require){return(
require('d3@7')
)}

function _foul_balls(FileAttachment){return(
FileAttachment("foul-balls.csv").csv()
)}

function _color(d3,foul_balls){return(
d3.scaleOrdinal(d3.schemePaired).domain(foul_balls.map(d => d.type))
)}

function _hitType(Inputs){return(
Inputs.select(
  new Map([
    ["All", "All"],
    ["Fly Ball", "Fly"],
    ["Ground Ball", "Ground"],
    ["Line Drive", "Line"],
    ["Pop Up", "Pop Up"],
    ["Batter hits self", "Batter hits self"]
  ]), 
  {label: "Batted Ball Type:", value: "All"}
)
)}

function _6(d3,hitType,foul_balls)
{
  const margin = {top: 20, right: 20, bottom: 20, left: 20};
  const width = 1000;
  const height = 800;

  // 1. Tooltip Creation
  d3.select(".foul-tooltip").remove(); 
  const tooltip = d3.select("body").append("div")
      .attr("class", "foul-tooltip")
      .style("position", "absolute")
      .style("visibility", "hidden")
      .style("background", "rgba(255, 255, 255, 0.95)")
      .style("border", "1px solid #333")
      .style("padding", "8px")
      .style("border-radius", "4px")
      .style("font-family", "sans-serif")
      .style("font-size", "12px")
      .style("pointer-events", "none")
      .style("z-index", "10");

  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height]);

  const g = svg.append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);


  const filteredData = hitType === "All" 
  ? foul_balls 
  : foul_balls.filter(d => d.type_of_hit === hitType);

  
  // 2. Data Aggregation
  const zoneStats = d3.rollup(filteredData, 
    v => ({
      total: v.length,
      avgVelo: d3.mean(v, d => d.exit_velocity ? +d.exit_velocity : null)
    }), 
    d => +d.used_zone
  );

  const maxFouls = d3.max(Array.from(zoneStats.values(), d => d.total)) || 0;
  const colorScale = d3.scaleSequential()
    .domain([0, maxFouls])
    .interpolator(d3.interpolateViridis);


  // 3. Field Background
  const field = g.append("g").attr("class", "field-background");

// Create a path that starts at Home, goes to Right Field, 
// curves to Left Field, and returns to Home.
  field.append("path")
  .attr("d", `
    M 500,700 
    L 850,350 
    Q 500,-100 150,350 
    Z
  `) 
  .attr("fill", "#6b8e23")
  .attr("stroke", "#fff")
  .attr("stroke-width", 2);


  // 4. Geometry with Centroids (Adding x,y for labels)
  const zones = [
    { id: 1, label: "Behind Home", x: 500, y: 730, path: "M450,700 L550,700 L530,760 L470,760 Z" },
    { id: 2, label: "3B Dugout", x: 420, y: 680, path: "M450,700 L320,630 L290,670 L450,740 Z" },
    { id: 3, label: "1B Dugout", x: 580, y: 680, path: "M550,700 L680,630 L710,670 L550,740 Z" },
    { id: 4, label: "3B Line Deep", x: 250, y: 550, path: "M320,630 L150,350 L100,400 L290,670 Z" },
    { id: 5, label: "1B Line Deep", x: 750, y: 550, path: "M680,630 L850,350 L900,400 L710,670 Z" },
    { id: 6, label: "3B Outfield", x: 120, y: 250, path: "M150,350 L250,50 L150,50 L50,300 Z" },
    { id: 7, label: "1B Outfield", x: 880, y: 250, path: "M850,350 L750,50 L850,50 L950,300 Z" }
  ];

  // 5. Draw Zones
  const paths = g.selectAll(".zone-path")
    .data(zones)
    .join("path")
    .attr("class", "zone-path")
    .attr("d", d => d.path)
    .attr("fill", d => {
      const s = zoneStats.get(d.id);
      return s ? colorScale(s.total) : "#eee";
    })
    .attr("stroke", "#fff")
    .style("cursor", "pointer")
    .on("mouseover", function(event, d) {
       const s = zoneStats.get(d.id);
       
       // Grey out effect
       paths.style("opacity", 0.1);
       d3.select(this).style("opacity", 1).attr("stroke", "#000");

       // Show Tooltip
       tooltip.style("visibility", "visible")
         .html(`
            <strong>Zone ${d.id}: ${d.label}</strong><br/>
            Fouls: ${s ? s.total : 0}<br/>
            Avg Velocity: ${s && s.avgVelo ? s.avgVelo.toFixed(1) + ' mph' : 'N/A'}
         `);
    })
    .on("mousemove", (event) => {
       tooltip.style("top", (event.pageY - 10) + "px")
              .style("left", (event.pageX + 15) + "px");
    })
    .on("mouseout", function() {
       paths.style("opacity", 1).attr("stroke", "#fff");
       tooltip.style("visibility", "hidden");
    });

  // 6. Draw Zone Numbers (Labels)
  g.selectAll(".zone-label")
    .data(zones)
    .join("text")
    .attr("class", "zone-label")
    .attr("x", d => d.x)
    .attr("y", d => d.y + 15)
    .attr("text-anchor", "middle")
    .attr("dominant-baseline", "middle")
    .style("pointer-events", "none")
    .style("font-family", "sans-serif")
    .style("font-weight", "bold")
    .style("fill", "#FFFFFF")
    .text(d => d.id);

  // 7. Legend (Uses maxFouls calculated earlier)
  const legendWidth = 200;
  const legend = g.append("g")
    .attr("transform", `translate(${width - legendWidth - 100}, 20)`);

  // ... [Gradient code from previous step] ...
  const defs = svg.append("defs");
  const linearGradient = defs.append("linearGradient").attr("id", "foul-gradient");
  linearGradient.selectAll("stop")
    .data(d3.range(0, 1.1, 0.1))
    .join("stop")
    .attr("offset", d => `${d * 100}%`)
    .attr("stop-color", d => d3.interpolateViridis(d));

  legend.append("rect")
    .attr("width", legendWidth).attr("height", 10)
    .style("fill", "url(#foul-gradient)");

  legend.append("text").attr("y", 25).style("font-size", "10px").text(`0 to ${maxFouls} Fouls`);

  return svg.node();
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["foul-balls.csv", {url: new URL("./files/1c1fe75702c0cf7ce4a2df7f0db1217bf2a71f42fb0fdd957fe908b0f50016d298da46f8bd20fd85017807188391f0303c07a51021f3e0c66ffee6049ce5b40a.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("foul_balls")).define("foul_balls", ["FileAttachment"], _foul_balls);
  main.variable(observer("color")).define("color", ["d3","foul_balls"], _color);
  main.variable(observer("viewof hitType")).define("viewof hitType", ["Inputs"], _hitType);
  main.variable(observer("hitType")).define("hitType", ["Generators", "viewof hitType"], (G, _) => G.input(_));
  main.variable(observer()).define(["d3","hitType","foul_balls"], _6);
  return main;
}
